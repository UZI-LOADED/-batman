from flask import Flask, render_template_string
app = Flask(__name__)

@app.route('/')
def dashboard():
    try:
        with open('../data/findings.txt') as f:
            findings = f.read().splitlines()
    except:
        findings = ["No findings yet."]
    html = '''
    <html><body style="background-color:black;color:white;font-family:monospace;">
    <h1>🦇 Dracula Recon Dashboard</h1>
    <ul>{% for line in findings %}<li>{{ line }}</li>{% endfor %}</ul>
    </body></html>
    '''
    return render_template_string(html, findings=findings)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
