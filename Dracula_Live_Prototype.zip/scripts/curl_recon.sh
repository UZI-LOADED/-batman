#!/bin/bash
TARGET=$1
OUTDIR="../data"

mkdir -p $OUTDIR

echo "[+] Fetching headers from $TARGET"
curl -s -D $OUTDIR/headers.txt -o $OUTDIR/body.html $TARGET

echo "[+] Searching for sensitive keywords..."
grep -Eoi "api[_-]?key|token|password|secret" $OUTDIR/body.html > $OUTDIR/findings.txt

echo "[+] Recon complete. Results in $OUTDIR"
